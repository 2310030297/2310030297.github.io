
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import ProjectDetail from "@/components/sections/ProjectDetail";

const ProjectPage = () => {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      <main>
        <ProjectDetail />
      </main>
      <Footer />
    </div>
  );
};

export default ProjectPage;
