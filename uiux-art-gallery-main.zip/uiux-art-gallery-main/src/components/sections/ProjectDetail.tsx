
import { ArrowLeft } from "lucide-react";
import { useNavigate, useParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { projects } from "@/data/projects";

const ProjectDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  
  // Find the project with the matching id
  const project = projects.find(p => p.id.toString() === id);
  
  // If project not found, show error message
  if (!project) {
    return (
      <div className="min-h-screen flex flex-col justify-center items-center px-4">
        <h1>Project not found</h1>
        <p className="mb-6 opacity-70">The project you're looking for doesn't exist.</p>
        <Button onClick={() => navigate('/')}>Back to home</Button>
      </div>
    );
  }

  return (
    <section className="py-20 px-4">
      <div className="container mx-auto max-w-4xl">
        <Button 
          variant="ghost" 
          onClick={() => navigate('/')} 
          className="mb-8 pl-2"
        >
          <ArrowLeft className="mr-2" size={16} />
          Back to projects
        </Button>

        <div className="bg-gradient-to-tr from-secondary to-accent p-1 rounded-lg mb-10">
          <div className="rounded-lg overflow-hidden">
            <img 
              src={project.image} 
              alt={project.title} 
              className="w-full h-auto object-cover"
            />
          </div>
        </div>

        <div className="space-y-6">
          <div>
            <span className="text-sm font-medium uppercase tracking-wider opacity-70">
              {project.category}
            </span>
            <h1 className="mt-2">{project.title}</h1>
          </div>

          <p className="text-lg opacity-75 leading-relaxed">
            {project.description}
          </p>

          <div className="py-4">
            <h2 className="text-xl font-bold mb-4">Project Overview</h2>
            <p className="opacity-75 mb-6">
              This project involved a detailed research phase, followed by wireframing and prototyping.
              The final solution was developed with a focus on user experience and accessibility.
            </p>

            <h3 className="text-lg font-semibold mb-2">Key Features</h3>
            <ul className="list-disc pl-5 space-y-2 opacity-75 mb-6">
              <li>Intuitive navigation and user flow</li>
              <li>Responsive design for all device sizes</li>
              <li>Accessible interface following WCAG guidelines</li>
              <li>Performance optimized interactions</li>
            </ul>

            <h3 className="text-lg font-semibold mb-2">Technologies Used</h3>
            <div className="flex flex-wrap gap-2 mb-8">
              <span className="px-3 py-1 bg-secondary/30 rounded-full text-sm">Figma</span>
              <span className="px-3 py-1 bg-secondary/30 rounded-full text-sm">Adobe XD</span>
              <span className="px-3 py-1 bg-secondary/30 rounded-full text-sm">Sketch</span>
              <span className="px-3 py-1 bg-secondary/30 rounded-full text-sm">InVision</span>
            </div>
          </div>

          <div className="pt-6 border-t">
            <h2 className="text-xl font-bold mb-4">Design Process</h2>
            <div className="space-y-8">
              <div>
                <h3 className="text-lg font-semibold mb-2">Research & Discovery</h3>
                <p className="opacity-75">
                  The project began with extensive user research to understand the target audience's needs and pain points.
                  Competitor analysis helped identify opportunities for differentiation.
                </p>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-2">Wireframing & Prototyping</h3>
                <p className="opacity-75">
                  Low-fidelity wireframes were created to establish the basic structure, followed by interactive prototypes
                  to test user flows and interactions.
                </p>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-2">Visual Design</h3>
                <p className="opacity-75">
                  The final visual design incorporated the brand's identity while ensuring a modern and intuitive user interface.
                  Emphasis was placed on accessibility and visual hierarchy.
                </p>
              </div>
            </div>
          </div>

          <div className="pt-10 flex justify-center">
            <Button size="lg" onClick={() => navigate('/')}>
              Back to all projects
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProjectDetail;
