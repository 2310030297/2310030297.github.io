import { useState } from "react";
import { Mail, MapPin, Phone, Github, Linkedin, Twitter } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
const ContactSection = () => {
  const {
    toast
  } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: ""
  });
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const {
      id,
      value
    } = e.target;
    setFormData(prev => ({
      ...prev,
      [id]: value
    }));
  };
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      // Simple client-side email validation
      if (!formData.email.includes('@')) {
        toast({
          title: "Invalid email",
          description: "Please enter a valid email address.",
          variant: "destructive"
        });
        setIsSubmitting(false);
        return;
      }

      // Email service endpoint (you would need to set up a backend service for this)
      const emailEndpoint = "https://formsubmit.co/sudinisaisantoshreddy@gmail.com";

      // Create form data
      const formDataToSend = new FormData();
      formDataToSend.append("name", formData.name);
      formDataToSend.append("email", formData.email);
      formDataToSend.append("subject", formData.subject);
      formDataToSend.append("message", formData.message);

      // Send the email using the FormSubmit service
      const response = await fetch(emailEndpoint, {
        method: "POST",
        body: formDataToSend,
        headers: {
          "Accept": "application/json"
        }
      });
      if (!response.ok) {
        throw new Error("Failed to send email");
      }

      // Show success message
      toast({
        title: "Message sent!",
        description: "Thank you for your message. We'll get back to you soon."
      });

      // Reset form fields
      setFormData({
        name: "",
        email: "",
        subject: "",
        message: ""
      });
    } catch (error) {
      console.error("Error sending message:", error);
      toast({
        title: "Error",
        description: "Failed to send your message. Please try again later.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  return <section id="contact" className="py-20 px-4">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16">
          <p className="text-sm font-medium uppercase tracking-wider opacity-70 mb-3">Get In Touch</p>
          <h2 className="mb-4">Let's Work Together</h2>
          <p className="text-lg opacity-75 max-w-2xl mx-auto">
            Interested in working together? Feel free to reach out. I'm always open to discussing new projects and creative ideas.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10">
          <div className="md:col-span-5 space-y-6 opacity-0 animate-fade-in" style={{
          animationDelay: '0.1s',
          animationFillMode: 'forwards'
        }}>
            <h3 className="text-2xl font-bold">Contact Information</h3>
            <p className="opacity-75">
              Fill out the form or contact me directly through the information below.
            </p>
            
            <Card className="border-none shadow-sm">
              <CardContent className="p-6 space-y-4 px-0">
                <div className="flex items-center gap-3">
                  <div className="bg-secondary p-3 rounded-full">
                    <Mail className="h-5 w-5" />
                  </div>
                  <div>
                    <div className="text-sm opacity-70">Email</div>
                    <div className="font-medium">sudinisaisantoshreddy@gmail.com</div>
                  </div>
                </div>
                
                <div className="flex items-center gap-3">
                  <div className="bg-secondary p-3 rounded-full">
                    <Phone className="h-5 w-5" />
                  </div>
                  <div>
                    <div className="text-sm opacity-70">Phone</div>
                    <div className="font-medium">+918185067669</div>
                  </div>
                </div>
                
                <div className="flex items-center gap-3">
                  <div className="bg-secondary p-3 rounded-full">
                    <MapPin className="h-5 w-5" />
                  </div>
                  <div>
                    <div className="text-sm opacity-70">Location</div>
                    <div className="font-medium">Hyderabad,Telangana</div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <div className="pt-4">
              <h4 className="text-lg font-semibold mb-3">Connect</h4>
              <div className="flex gap-3">
                <a href="#" className="bg-secondary p-3 rounded-full hover:bg-primary hover:text-primary-foreground transition-colors">
                  <Linkedin className="h-5 w-5" />
                </a>
                <a href="#" className="bg-secondary p-3 rounded-full hover:bg-primary hover:text-primary-foreground transition-colors">
                  <Github className="https://www.linkedin.com/in/sudini-sai-santosh-reddy-839b52201/" />
                </a>
                <a href="#" className="bg-secondary p-3 rounded-full hover:bg-primary hover:text-primary-foreground transition-colors">
                  <Twitter className="h-5 w-5" />
                </a>
              </div>
            </div>
          </div>
          
          <div className="md:col-span-7 opacity-0 animate-fade-in-up" style={{
          animationDelay: '0.2s',
          animationFillMode: 'forwards'
        }}>
            <form className="space-y-6" onSubmit={handleSubmit} action="https://formsubmit.co/sudinisaisantoshreddy@gmail.com" method="POST">
              <input type="hidden" name="_subject" value="New portfolio contact message" />
              <input type="hidden" name="_captcha" value="false" />
              <input type="hidden" name="_next" value={window.location.href} />
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label htmlFor="name" className="text-sm font-medium">
                    Name
                  </label>
                  <Input id="name" name="name" placeholder="Your name" required value={formData.name} onChange={handleChange} />
                </div>
                <div className="space-y-2">
                  <label htmlFor="email" className="text-sm font-medium">
                    Email
                  </label>
                  <Input id="email" name="email" type="email" placeholder="Your email address" required value={formData.email} onChange={handleChange} />
                </div>
              </div>
              
              <div className="space-y-2">
                <label htmlFor="subject" className="text-sm font-medium">
                  Subject
                </label>
                <Input id="subject" name="subject" placeholder="What's this about?" required value={formData.subject} onChange={handleChange} />
              </div>
              
              <div className="space-y-2">
                <label htmlFor="message" className="text-sm font-medium">
                  Message
                </label>
                <Textarea id="message" name="message" placeholder="Tell me about your project..." rows={6} required value={formData.message} onChange={handleChange} />
              </div>
              
              <Button type="submit" size="lg" className="w-full sm:w-auto" disabled={isSubmitting}>
                {isSubmitting ? "Sending..." : "Send Message"}
              </Button>
            </form>
          </div>
        </div>
      </div>
    </section>;
};
export default ContactSection;