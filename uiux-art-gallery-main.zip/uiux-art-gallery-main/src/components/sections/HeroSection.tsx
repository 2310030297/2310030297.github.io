
import { ArrowDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const HeroSection = () => {
  return <section id="hero" className="min-h-screen flex flex-col justify-center items-center pt-16 pb-10 px-4">
      <div className="container mx-auto max-w-5xl">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
          <div className="md:col-span-7 space-y-6">
            <p className="text-sm font-medium uppercase tracking-wider opacity-70 animate-fade-in">
              UI/UX Designer
            </p>
            <h1 className="animate-fade-in animate-delay-100">
              Crafting Digital <span className="highlight">Experiences</span> That People Love
            </h1>
            <p className="text-lg md:text-xl opacity-75 leading-relaxed max-w-xl animate-fade-in animate-delay-200">
              I design intuitive digital experiences that help businesses connect with their customers in meaningful ways.
            </p>
            <div className="flex flex-wrap gap-4 pt-4 animate-fade-in animate-delay-300">
              <Button size="lg" asChild>
                <a href="#projects">View my work</a>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <a href="#contact">Contact me</a>
              </Button>
            </div>
          </div>
          <div className="md:col-span-5 animate-fade-in animate-delay-400">
            <div className="bg-gradient-to-tr from-secondary to-accent p-1 rounded-lg">
              <div className="aspect-square rounded-lg bg-muted/50 flex items-center justify-center overflow-hidden">
                <img alt="Designer workspace with tablet and design tools" src="/lovable-uploads/34b9ebf0-4726-4277-8fbd-8915f6a0b15a.png" className="w-full h-full object-fill" />
              </div>
            </div>
          </div>
        </div>
        
        <div className="mt-20 flex justify-center animate-fade-in animate-delay-500">
          <a href="#projects" className="flex flex-col items-center gap-2 opacity-70 hover:opacity-100 transition-opacity">
            <span className="text-sm font-medium">Scroll to see my work</span>
            <ArrowDown size={20} className="animate-bounce" />
          </a>
        </div>
      </div>
    </section>;
};
export default HeroSection;
