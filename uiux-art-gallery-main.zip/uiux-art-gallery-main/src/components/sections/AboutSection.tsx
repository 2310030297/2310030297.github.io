
import { CheckCircle } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";

const skills = [
  "User Research", "Wireframing", "Prototyping", 
  "Interaction Design", "Visual Design", "Usability Testing",
  "Design Systems", "UI Animation", "Design Thinking"
];

const AboutSection = () => {
  return (
    <section id="about" className="py-20 px-4 bg-secondary/30">
      <div className="container mx-auto max-w-6xl">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 items-center">
          <div className="md:col-span-5 opacity-0 animate-fade-in" style={{ animationDelay: '0.1s', animationFillMode: 'forwards' }}>
            <div className="rounded-lg overflow-hidden">
              <img 
                src="https://images.unsplash.com/photo-1531538606174-0f90ff5dce83?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1374&q=80" 
                alt="Designer at work" 
                className="w-full h-auto"
              />
            </div>
          </div>
          
          <div className="md:col-span-7 space-y-6 opacity-0 animate-fade-in-up" style={{ animationDelay: '0.2s', animationFillMode: 'forwards' }}>
            <p className="text-sm font-medium uppercase tracking-wider opacity-70">
              About Me
            </p>
            <h2>Passionate UI/UX Designer Creating Meaningful Experiences</h2>
            <p className="text-lg opacity-75 leading-relaxed">
              I'm a UI/UX designer with over 5 years of experience crafting digital products that users love. My approach combines creativity with data-driven insights to design solutions that are both beautiful and functional.
            </p>
            
            <Separator className="my-8" />
            
            <div>
              <h3 className="text-xl font-bold mb-4">My Design Process</h3>
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <CheckCircle className="h-5 w-5 text-primary mt-0.5 shrink-0" />
                  <div>
                    <h4 className="font-bold">Research & Discovery</h4>
                    <p className="opacity-75">Understanding user needs and business goals through thorough research.</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle className="h-5 w-5 text-primary mt-0.5 shrink-0" />
                  <div>
                    <h4 className="font-bold">Ideation & Wireframing</h4>
                    <p className="opacity-75">Sketching ideas and creating wireframes to establish structure and flow.</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle className="h-5 w-5 text-primary mt-0.5 shrink-0" />
                  <div>
                    <h4 className="font-bold">Design & Prototyping</h4>
                    <p className="opacity-75">Creating high-fidelity designs and interactive prototypes for testing.</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle className="h-5 w-5 text-primary mt-0.5 shrink-0" />
                  <div>
                    <h4 className="font-bold">Testing & Iteration</h4>
                    <p className="opacity-75">Gathering feedback and refining the design for optimal user experience.</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="pt-6">
              <h3 className="text-xl font-bold mb-4">Skills & Expertise</h3>
              <div className="flex flex-wrap gap-2">
                {skills.map((skill) => (
                  <Badge key={skill} variant="secondary" className="px-3 py-1.5">
                    {skill}
                  </Badge>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
