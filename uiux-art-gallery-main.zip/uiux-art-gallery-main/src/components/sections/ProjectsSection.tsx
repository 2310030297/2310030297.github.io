
import { ExternalLink } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { projects } from "@/data/projects";

const ProjectsSection = () => {
  return (
    <section id="projects" className="py-20 px-4">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16">
          <p className="text-sm font-medium uppercase tracking-wider opacity-70 mb-3">Portfolio</p>
          <h2 className="mb-4">Featured Projects</h2>
          <p className="text-lg opacity-75 max-w-2xl mx-auto">
            Explore a selection of my recent work across various industries and platforms.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <div 
              key={project.id} 
              className={`opacity-0 animate-fade-in-up`} 
              style={{ animationDelay: `${index * 0.1 + 0.1}s`, animationFillMode: 'forwards' }}
            >
              <Card className="h-full overflow-hidden hover:shadow-lg transition-shadow">
                <div className="aspect-[4/3] overflow-hidden">
                  <img 
                    src={project.image} 
                    alt={project.title} 
                    className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
                  />
                </div>
                <CardContent className="p-6">
                  <div className="mb-2">
                    <span className="text-xs font-medium uppercase tracking-wider opacity-70">
                      {project.category}
                    </span>
                  </div>
                  <h3 className="text-xl font-bold mb-2">{project.title}</h3>
                  <p className="opacity-75 mb-4">{project.description}</p>
                  <Button variant="outline" size="sm" asChild>
                    <Link to={project.link} className="inline-flex items-center gap-1">
                      View case study <ExternalLink size={14} />
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            </div>
          ))}
        </div>
        
        <div className="mt-16 text-center opacity-0 animate-fade-in" style={{ animationDelay: '0.4s', animationFillMode: 'forwards' }}>
          <Button size="lg">View all projects</Button>
        </div>
      </div>
    </section>
  );
};

export default ProjectsSection;
