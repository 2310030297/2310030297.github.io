
import { Separator } from "@/components/ui/separator";

const Footer = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="py-12 px-4 bg-secondary/50">
      <div className="container mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-6 md:mb-0">
            <a href="#hero" className="text-xl font-display font-bold">
              design<span className="text-black/70">portfolio</span>
            </a>
            <p className="text-sm opacity-70 mt-2">
              Creating meaningful digital experiences
            </p>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-6 sm:gap-12 text-center sm:text-left">
            <div>
              <h4 className="font-semibold mb-3">Navigation</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#hero" className="opacity-70 hover:opacity-100 transition-opacity">Home</a></li>
                <li><a href="#projects" className="opacity-70 hover:opacity-100 transition-opacity">Projects</a></li>
                <li><a href="#about" className="opacity-70 hover:opacity-100 transition-opacity">About</a></li>
                <li><a href="#contact" className="opacity-70 hover:opacity-100 transition-opacity">Contact</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-3">Legal</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="opacity-70 hover:opacity-100 transition-opacity">Privacy Policy</a></li>
                <li><a href="#" className="opacity-70 hover:opacity-100 transition-opacity">Terms of Service</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-3">Social</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="opacity-70 hover:opacity-100 transition-opacity">LinkedIn</a></li>
                <li><a href="#" className="opacity-70 hover:opacity-100 transition-opacity">GitHub</a></li>
                <li><a href="#" className="opacity-70 hover:opacity-100 transition-opacity">Twitter</a></li>
              </ul>
            </div>
          </div>
        </div>
        
        <Separator className="my-8" />
        
        <div className="text-center text-sm opacity-70">
          <p>&copy; {currentYear} UI/UX Design Portfolio. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
