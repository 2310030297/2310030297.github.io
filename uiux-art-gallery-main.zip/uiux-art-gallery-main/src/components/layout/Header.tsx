
import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', url: '#hero' },
    { name: 'Projects', url: '#projects' },
    { name: 'About', url: '#about' },
    { name: 'Contact', url: '#contact' }
  ];

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);

  return (
    <header 
      className={`fixed w-full top-0 z-50 transition-all duration-300 px-4 md:px-6 
        ${isScrolled ? 'bg-white/90 backdrop-blur-sm shadow-sm py-3' : 'bg-transparent py-5'}`}
    >
      <div className="container mx-auto flex justify-between items-center">
        <a href="#hero" className="text-xl font-display font-bold">
          design<span className="text-black/70">portfolio</span>
        </a>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          {navLinks.map((link) => (
            <a 
              key={link.name} 
              href={link.url} 
              className="text-sm font-medium transition-colors hover:text-primary/80"
            >
              {link.name}
            </a>
          ))}
          <Button>Get in touch</Button>
        </nav>

        {/* Mobile Menu Button */}
        <button 
          className="md:hidden flex items-center" 
          onClick={toggleMenu}
          aria-label={isMenuOpen ? "Close menu" : "Open menu"}
        >
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
        
        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="absolute top-full left-0 right-0 bg-white p-4 shadow-md md:hidden animate-fade-in">
            <nav className="flex flex-col space-y-4">
              {navLinks.map((link) => (
                <a 
                  key={link.name} 
                  href={link.url}
                  onClick={toggleMenu}
                  className="text-base font-medium py-2 transition-colors hover:text-primary/80"
                >
                  {link.name}
                </a>
              ))}
              <Button className="w-full">Get in touch</Button>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
