
export const projects = [
  {
    id: 1,
    title: "Finance App Redesign",
    category: "Mobile App",
    description: "A complete redesign of a finance application focusing on simplicity and user experience.",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80",
    link: "/projects/1"
  },
  {
    id: 2,
    title: "E-commerce Website",
    category: "Web Design",
    description: "A clean, modern e-commerce platform with intuitive navigation and seamless checkout flow.",
    image: "https://images.unsplash.com/photo-1593642702821-c8da6771f0c6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1332&q=80",
    link: "/projects/2"
  },
  {
    id: 3,
    title: "Health & Fitness App",
    category: "UI/UX Design",
    description: "An engaging fitness application with intuitive workout tracking and progress visualization.",
    image: "https://images.unsplash.com/photo-1555774698-0b77e0d5fac6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80",
    link: "/projects/3"
  }
];
